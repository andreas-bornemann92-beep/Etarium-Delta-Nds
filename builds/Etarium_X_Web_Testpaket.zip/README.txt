ETARIUM X – WEB-TESTPAKET

Starte etarium-x.html im Browser, nachdem das ZIP vollständig entpackt wurde.
Empfohlen: über einen lokalen HTTP-Server auf dem Computer oder über GitHub Pages.
Dies ist KEINE Nintendo-DS-ROM und kann nicht als .nds in Delta gestartet werden.

Inhalt: 100 erreichbare Dialoge, 4 NPCs, 4 betretbare Häuser, zweiründiger Trainingskampf mit automatischem Sieg, 18 einfache Charaktervarianten, getrennte Spielstände.

Stand: 30.10.2026
